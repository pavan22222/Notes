package com.infinite;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBoot1EurekaServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
