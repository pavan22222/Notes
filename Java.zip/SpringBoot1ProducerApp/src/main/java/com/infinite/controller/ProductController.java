package com.infinite.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infinite.entity.Product;
import com.infinite.service.ProductService;

@RestController
@RequestMapping("/product")
public class ProductController {
	
	@Autowired
	private ProductService productService;
	
	@PostMapping(value = "/saveProduct")
	public ResponseEntity<Integer> saveProduct(@RequestBody(required = true) Product product){
		return new ResponseEntity<Integer>(productService.registerProduct(product), HttpStatus.OK);
	}
	
	@PutMapping(value = "/updateProduct")
	public ResponseEntity<Integer> updateProduct(@RequestBody(required = true) Product product){
		return new ResponseEntity<Integer>(productService.updateProduct(product), HttpStatus.OK);
	}
	
	@DeleteMapping(value = "/deleteProduct")
	public ResponseEntity<String> deleteProduct(@RequestBody(required = true) Product product){
		return new ResponseEntity<String>(productService.deleteProduct(product), HttpStatus.OK);
	}
	
	@GetMapping(value = "/getProduct/{productId}")
	public ResponseEntity<Product> getProduct(@PathVariable(required = true)Integer  productId){
		return new ResponseEntity<Product>(productService.getProduct(productId), HttpStatus.OK);
	}
	
	@PostMapping(value = "/getAllProduct")
	public ResponseEntity<List<Product>> saveProduct(@RequestBody(required = true) List<Integer> productIds){
		return new ResponseEntity<List<Product>>(productService.getAllProducts(productIds), HttpStatus.OK);
	}

}
