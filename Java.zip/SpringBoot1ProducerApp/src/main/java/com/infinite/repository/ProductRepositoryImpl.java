package com.infinite.repository;

public class ProductRepositoryImpl {

}
