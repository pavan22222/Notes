package com.infinite.service;

import com.infinite.entity.Product;

import java.util.List;

public interface ProductService {
	
	Integer registerProduct(Product product);
	
	Integer updateProduct(Product product);
	
	String deleteProduct(Product product);
	
	Product getProduct(Integer productId);
	
	List<Product> getAllProducts(List<Integer> productIds);

}
