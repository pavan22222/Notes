package com.infinite.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infinite.entity.Product;
import com.infinite.repository.ProductRepository;


@Service
@Transactional
public class ProductServiceImpl implements ProductService {
	
	@Autowired
	private ProductRepository productRepository;
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public Integer registerProduct(Product product) {
		return productRepository.save(product).getId();
	}

	@Override
	public Integer updateProduct(Product product) {
		Session session = (Session) entityManager.getDelegate();
		return ((Product)session.merge(product)).getId();
	}

	@Override
	public String deleteProduct(Product product) {
		productRepository.deleteById(product.getId());
		return "Deleted the record"+ product.getId();
	}

	@Override
	public Product getProduct(Integer productId) {
		return productRepository.findById(productId).get();
	}

	@Override
	public List<Product> getAllProducts(List<Integer> productIds) {
		return (List<Product>) productRepository.findAllById(productIds);
	}

}
