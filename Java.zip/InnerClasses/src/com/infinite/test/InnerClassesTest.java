package com.infinite.test;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class InnerClassesTest {

	public static void main(String[] args) {
		//sortStudents();
		Employee emp=new InnerClassesTest().new Employee();
		Student st=new InnerClassesTest.Student("1");
		comparator.compare(null, null);
	
	}
	
	//Member Inner class
	private class Employee{
		private Integer id;
		private String name;
		
		
		
		public Integer getId() {
			return id;
		}

		public void setId(Integer id) {
			this.id = id;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public <T extends Employee> T saveEmployee(T t){
			return t;
		}
		
		public <S extends Employee> S getObject(Class<? extends Employee> T){
			return (S) new Employee();
		}
		
		public void getDetails(String s) {
			
		}
		
	}
	
	
	//Nested Static Class
	private static class Student implements Comparable<Student>{
		private String id;
		
		
		private String getId() {
			return id;
		}
		
		Student(String id){
			this.id=id;
		}

		@Override
		public int compareTo(Student s) {
			return Integer.valueOf(this.getId()) > Integer.valueOf(s.getId()) ? -1
					: Integer.valueOf(this.getId()) < Integer.valueOf(s.getId()) ? 1 : 0;
		}

		@Override
		public String toString() {
			return "Student [id=" + id + "]";
		}
		
		
	}
	
	
	//Anonymus inner class
	static Comparator comparator = new Comparator() {

	
		@Override
		public int compare(Object o1, Object o2) {
			// TODO Auto-generated method stub
			return 0;
		}
	};
		
	
	private static void sortStudents() {
		
		class StudentComparator implements Comparator<Student>{

			@Override
			public int compare(Student s1, Student s2) {
				return Integer.valueOf(s1.getId()) > Integer.valueOf(s2.getId()) ? -1
						: Integer.valueOf(s1.getId()) < Integer.valueOf(s2.getId()) ? 1 : 0;
			}
			
		}
		List<Student> list= new ArrayList<Student>();
		list.add(new Student("1"));
		list.add(new Student("2"));
		list.add(new Student("3"));
		
		List<String> list1= new ArrayList<String>();
		list1.add("Pavan");
		list1.add("ABC");
		
		/*
		 * list.stream().sorted(Comparator.comparing(Student::getId).reversed()).collect
		 * (Collectors.toList()). forEach(System.out::println);
		 * 
		 * 
		 * list.stream().sorted().collect(Collectors.toList()).
		 * forEach(System.out::println);
		 */
		
		//list.sort(new StudentComparator());
		list.forEach(System.out::println);
	}
	
	
	

}
