package com.infinite.test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class LogicalPrograms {
	
	public static void main(String[] args) {
		findDuplicates();
		findDuplicatesWithLoops();
		sortingElementsBasedOnKeys();
		sortingElementsList();
		primeNumber();
		palindrome();
		showfibonacci(10);
	}
	
	
	private static void findDuplicates() {
		Integer[] array={1,3,4,5,6,1,3};
		List<Integer> list=Arrays.asList(array);
		List<Integer> duplicates=new ArrayList<Integer>();
		for(int i=0;i<list.size();i++) {
			if(list.lastIndexOf(list.get(i)) != i)
				duplicates.add(list.get(i));
		}
		System.out.println(duplicates);
	}
	
	private static void findDuplicatesWithLoops() {
		Integer[] array={5,1,3,4,5,6,1,3};
		List<Integer> duplicates=new ArrayList<Integer>();
		for(int i=0;i<array.length;i++) {
			for(int j=i+1;j<array.length;j++) {
				if(array[i] == array[j])
					duplicates.add(array[i]);
			}
		}
		System.out.println(duplicates);
	}
	
	private static void sortingElementsBasedOnKeys() {
		Map<String,Integer> map=new HashMap<String,Integer>();
		map.put("C", 1);
		map.put("A", 2);
		map.put("T", 3);
		map.put("L", 4);
		map.put("B", 5);
		map.put("C", 8);
		Map<String, Integer> newMapSortedByKey = map.entrySet().stream()
				.sorted((e1, e2) -> e1.getKey().compareTo(e2.getKey()))
				.collect(Collectors.toMap(Map.Entry<String, Integer>::getKey, Map.Entry<String, Integer>::getValue,
						(e1, e2) -> e1, LinkedHashMap::new));
		Set<Map.Entry<String, Integer>> entrySet = newMapSortedByKey.entrySet();
		System.out.println(newMapSortedByKey);
	}
	
	private static void sortingElementsList() {
		List<Integer> list=new ArrayList<Integer>();
		list.add(12);
		list.add(1);
		list.add(23);
		list.add(34);
		list.add(2);
		list.add(2);
		list.add(1);
		//list.stream().sorted((a,b) -> -a.compareTo(b)).collect(Collectors.toList()).forEach(System.out::println);
		list.stream().sorted(Comparator.reverseOrder()).collect(Collectors.toList()).forEach(System.out::println);
		Collections.sort(list, (a,b) -> -a.compareTo(b));
		Collections.sort(list);
		System.out.println(list);
	}
	
	private static void primeNumber() {
		Integer number=3;
		int count=0;
		for(int i=1;i<=3;i++) {
			if(51 % i == 0)
				count++;
		}
		System.out.println( count == 2 ? "Prime Number" +count:"Not a Prime Number"+count);
	}
	
	private static void palindrome() {
		int number=333;
		int rem,sum=0,temp=number;
		while(number > 0) {
			rem=number%10;
			sum=(sum*10)+rem;
			number=number/10;
		}
		System.out.println(sum+" "+temp);
		System.out.println(sum==temp);
		System.out.println( temp == sum ? "palindrome" : " Not a Palindrome");
	}
	
	  static void showfibonacci(int no){
		  int f1, f2=0, f3=1;
			/*
			 * int f1=0, f2=1, f3=f1+f2; System.out.print(f1+" "+ f2);
			 */
          for(int i=1;i <=no;i++){
                System.out.print(" "+f3);
                f1 = f2;
                f2 = f3;
                f3 = f1 + f2;
          }
          
          Set<Integer> set=new HashSet<Integer>();
	  }

}
