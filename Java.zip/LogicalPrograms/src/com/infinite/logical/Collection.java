package com.infinite.logical;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Objects;

public class Collection {

	public static void main(String[] args) {
		
		List<Student> students = new ArrayList<Student>();
		students.add(new Student(1,"Adams",21,new Date()));
		students.add(new Student(2,"Jhonson",40,new Date()));
		students.add(new Student(3,"Smith",33,new Date()));
		students.add(new Student(4,"Buttler",32,new Date()));
		//addAll
		Collections.addAll(students,new Student(5,"Root",35,new Date("2000/12/01")));
		System.out.println(students);
		//bindarySearch
		System.out.println(Collections.binarySearch(students,new Student(1,"Adams",21,new Date())));
		List<Student> newstudentsList = new ArrayList<Student>();
		newstudentsList = Arrays.asList(Arrays.copyOf(students.toArray(new Student[0]),students.size()));
		//Collections.copy(newstudentsList,students);
		System.out.println(Arrays.deepToString(newstudentsList.toArray()));
		//emptyList()
		List<Student> emptyList = Collections.emptyList();
		System.out.println(emptyList);
		//fill
		Collections.fill(newstudentsList, new Student(6,"Guptil",38,new Date("1990/12/01")));
		System.out.println(newstudentsList);
		//frequency
		System.out.println(Collections.frequency(newstudentsList, new Student(6,"Guptil",38,new Date("1990/12/01"))));
		//max
		System.out.println(Collections.max(students));
		//min
		System.out.println(Collections.min(students));
		//sort
		Collections.sort(students);
		System.out.println(students);
		//sort(list,comparator)
		Collections.sort(students,(student1,student2) -> student1.getId() > student2.getId() ? -1 :
			student1.getId() < student2.getId() ? 1 :0);
		System.out.println(students);
	}

}

class Student implements Comparable<Student> {

	private Integer id;
	private String name;
	private Integer age;
	private Date doj;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public Date getDoj() {
		return doj;
	}

	public void setDoj(Date doj) {
		this.doj = doj;
	}

	public Student() {

	}

	public Student(Integer id, String name, Integer age, Date doj) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
		this.doj = doj;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Student other = (Student) obj;
		return Objects.equals(age, other.age) && Objects.equals(doj, other.doj) && Objects.equals(id, other.id)
				&& Objects.equals(name, other.name);
	}

	@Override
	public int compareTo(Student student) {
		return getId() > student.getId() ? 1 : getId() > student.getId() ? -1 : 0;
	}

	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", age=" + age + ", doj=" + doj + "]";
	}
	
	
}
