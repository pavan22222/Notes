package com.infinite.logical;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.stream.Collectors;

import javax.print.attribute.HashAttributeSet;

public class StringManipulations {
	
	
	
	public static void main(String[] args) throws InstantiationException, IllegalAccessException {
		System.out.println((int)'a' +" " + (int)'z' + " "+ (int)'A' +" " + (int)'Z');
		System.out.println(isCharacterExists('a', "Pavan"));
		System.out.println("count ::"+countOfCharacter('a', "Pavan"));
		printCaseOfEachCharacter("PavAn");
		sortStringsByLength("Pavan","Java","SQL Server");
		System.out.println(sortString("Pavan"));
		getObject(String.class);
	}
	
	public static boolean isCharacterExists(char ch,String string) {
		return string.contains(String.valueOf(ch));
	}
	
	public static int countOfCharacter(char ch,String string) {
		int count=0;
		for(int i=0;i<string.length();i++) {
			if(String.valueOf(ch).equals(String.valueOf(string.charAt(i))))
				count++;				
		}
		return count;
	}
	
	public static void printCaseOfEachCharacter(String str) {
		for(int i=0;i<str.length();i++) {
			if(str.charAt(i) >= 65 && str.charAt(i) <= 90)
				System.out.println(str.charAt(i) +" is Upper Case");
			else
				System.out.println(str.charAt(i) +" is Lower Case");
		}
	}
	
	public static void sortStringsByLength(String... args) {
		List<String> list=Arrays.asList(args);
		List<String> sortedList = list.stream().sorted((s1,s2)->s1.length() > s2.length() ? -1 : s1.length() < s2.length() ? 1 : 0 ).collect(Collectors.toList());
		System.out.println(sortedList);
	}
	
	public static String sortString(String str){
		Character[] array1 = str.chars().mapToObj(i -> (char)i).toArray(Character[] :: new);

		List<Character> list = Arrays.asList(array1);
		list.stream().sorted((ch1, ch2) -> ch1 > ch2 ? 1 : ch1 < ch2 ? -1 : 0).collect(Collectors.toList());
		System.out.println(list);
		System.out.println(str.getClass().getName());
		char[] array=str.toCharArray();
		Arrays.sort(array);
		System.out.println(array);
		return String.valueOf(array);
	}
	
	public static <S extends String> S getObject(Class<? extends String> T ) throws InstantiationException, IllegalAccessException{
		System.out.println(T.getClass().getName());
		Object obj=T.newInstance();
		if(!(obj instanceof String))
			throw new IllegalAccessError("Invalid class Type");
		return (S) new String();
	}

}
