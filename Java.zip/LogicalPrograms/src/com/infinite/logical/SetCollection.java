package com.infinite.logical;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Set;

public class SetCollection {
	
	public static void main(String[] args) {
		
		
		
		Set<Integer> set1 = new HashSet();
		set1.add(null);
		set1.add(null);
		System.out.println(set1);
		
		Set<Integer> set2 = new HashSet();
		set2.add(12);
		set2.add(14);
		set2.add(10);
		set2.add(8);
		System.out.println(set2);
		
		Set<Integer> set3 = new LinkedHashSet();
		set3.add(12);
		set3.add(14);
		set3.add(10);
		set3.add(8);
		System.out.println(set3);
		
		Iterator iterator = set3.iterator();
		while(iterator.hasNext()) {
			System.out.println(iterator.next());
		}
		
		List<Integer> list=new ArrayList<Integer>(set3);
		ListIterator<Integer> listIterator= list.listIterator();
		System.out.println(list);
		while(listIterator.hasNext()) {
			//listIterator.set(listIterator.next() + 20);
			System.out.println(listIterator.next());
		}
		
		while(listIterator.hasPrevious()) {
			//listIterator.set(listIterator.next() + 20);
			System.out.println(listIterator.previous());
		}
		
		Map<Integer,String> map=new HashMap<Integer, String>();
		map.put(1, "Pavan");
		System.out.println(map);
		
	}

}
