package com.infinite.logical;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Anagram {

	public static void main(String[] args) {
		
		char[] array= {'a','c','b'};
		System.out.println(new String(array).equals("acb"));
		findAnagramOfStrings("Pavan", "aPvan");
		List<List<String>> anagramsList=findAnagramOfStringsArray("eat","ate","tae","tab","bat","cat");
		System.out.println(anagramsList);
	}

	public static Boolean findAnagramOfStrings(String str1, String str2) {
		if (str1.length() == str2.length()) {
			char[] array1=str1.toCharArray();
			char[] array2=str2.toCharArray();
			Arrays.sort(array1);
			Arrays.sort(array2);
			return Arrays.equals(array1, array2);
		} else
			return false;
	}
	
	
	public static List<List<String>> findAnagramOfStringsArray(String... args) {
		List<List<String>> anagramsList=new ArrayList<List<String>>();
		for(int i=0;i<args.length;i++) {
			boolean flag=true;
			for(List<String> anagram:anagramsList) {
				if(checkAnagramInList(anagram,args[i])) {
					anagram.add(args[i]);
					flag = false;
				}
			}
			if(flag) {
				List<String> anagram=new ArrayList<String>();
				anagram.add(args[i]);
				anagramsList.add(anagram);
			}
				
		}
		
		return anagramsList;
	} 
	
	
	public static boolean checkAnagramInList(List<String> list, String str) {
		for (String string : list) {
			if (findAnagramOfStrings(string, str)) {
				return true;
			}
		}
		return false;
	}

}