package com.infinite.logical;

import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Objects;


public class Array {
	
	public static void main(String[] args) {
		String s1 = "Pavan";
		String s2 = "Pavan12";
		System.out.println(Arrays.asList(s1, s2));
		System.out.println(Arrays.binarySearch(new float[] { 12.0f, 15f, 24f, 78 }, 15.20f));
		Employee employee1 = new Employee(1, "Pavan", 13, new Date("2022/12/12"));
		Employee employee2 = new Employee(2, "Adams", 13, new Date("2010/12/10"));
		Employee employee3 = new Employee(3, "Jhonson", 13, new Date("2009/10/12"));
		Employee employee4 = new Employee(4, "Jacobs", 13, new Date("2008/01/06"));
		List<Employee> employees = Arrays.asList(employee1, employee2, employee3, employee4);
		
		Employee employee11 = new Employee(1, "Pavan", 13, new Date("2022/12/12"));
		Employee employee22 = new Employee(2, "Adams", 13, new Date("2010/12/10"));
		Employee employee33 = new Employee(3, "Jhonson", 13, new Date("2009/10/12"));
		Employee employee44= new Employee(4, "Jacobs", 13, new Date("2008/01/06"));
		List<Employee> employees2 = Arrays.asList(employee11, employee22, employee33, employee44);
		System.out.println(Arrays.binarySearch(employees.toArray(), employee3));
		List<Object> copiedEmployees = Arrays.asList(Arrays.copyOf(employees.toArray(), 3));
		System.out.println(copiedEmployees);
		System.out.println(Arrays.equals(new int[] { 1, 2, 3, 4, 5, 6 }, new int[] { 1, 2, 3, 4, 5, 6}));
		System.out.println(Arrays.equals(employees.toArray(),employees2.toArray()));
		int[] newArray = Arrays.copyOfRange(new int[] {1,2,43,4,4,55,44,98}, 8, 100);
		System.out.println(Arrays.toString(newArray));
		System.out.println(Arrays.deepEquals(employees.toArray(), employees2.toArray()));
		Long[]  longArray=new Long[] {1l,2l,43l,14l,64l}; 
		//Arrays.fill(longArray, 1l);
		Arrays.fill(longArray, 4,5,10l);
		System.out.println(Arrays.toString(longArray));
		//Arrays.sort(longArray,Comparator.reverseOrder());
		System.out.println(Arrays.toString(longArray));
		
		System.out.println(Arrays.toString(longArray));
		Arrays.sort(longArray,0,2,Comparator.reverseOrder());
		System.out.println(Arrays.toString(longArray));
	}

}


class Employee implements Comparable<Employee>{
	
	private Integer id;
	private String name;
	private Integer age;
	private Date doj;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	public Date getDoj() {
		return doj;
	}
	public void setDoj(Date doj) {
		this.doj = doj;
	}
	
	public Employee() {
		
	}
	
	public Employee(Integer id, String name, Integer age, Date doj) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
		this.doj = doj;
	}
	
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		return Objects.equals(age, other.age) && Objects.equals(doj, other.doj) && Objects.equals(id, other.id)
				&& Objects.equals(name, other.name);
	}
	
	
	@Override
	public int compareTo(Employee employee) {		
		return getId() > employee.getId() ? 1 : getId() > employee.getId() ? -1 :0;
	}

}
