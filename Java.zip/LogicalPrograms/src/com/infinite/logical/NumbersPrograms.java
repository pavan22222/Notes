package com.infinite.logical;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class NumbersPrograms {
	
	
	public static void main(String[] args) {
		//printUniqueNumbers(2,3,5,6,7,2,4,5,7,8);
		printDuplicateNumbers(2,3,5,6,7,2,4,5,7,8);
		removeSecondOccurenceOfDuplicateNumbers(2,3,5,6,7,2,4,5,7,8);
	}

	public static void printUniqueNumbers(Integer... args) {
		List<Integer> list = Arrays.asList(args);
		Set<Integer> set = new HashSet<Integer>();
		List<Integer> checkedList = new ArrayList<Integer>();
		for (int i = 0; i < list.size(); i++) {
			if (list.lastIndexOf(list.get(i)) == i && !checkedList.contains(list.get(i)))
				set.add(list.get(i));
			else
				checkedList.add(list.get(i));
		}

		System.out.println(set);
		System.out.println(checkedList);

	}
	
	public static void printDuplicateNumbers(Integer... args) {
		List<Integer> list = Arrays.asList(args);
		Set<Integer> duplicateNumbers=new HashSet<Integer>();
		for(int i=0;i<list.size();i++) {
			if(list.lastIndexOf(list.get(i)) != i)
				duplicateNumbers.add(list.get(i));
		}
		System.out.println(duplicateNumbers);
	}
	
	public static void removeSecondOccurenceOfDuplicateNumbers(Integer... args) {
		List<Integer> list = Arrays.asList(args);
		Set<Integer> duplicateNumbers=new HashSet<Integer>();
		for(int i=0;i<list.size();i++) {
			if(list.lastIndexOf(list.get(i)) == i)
				duplicateNumbers.add(list.get(i));
		}
		System.out.println(duplicateNumbers);
	}
}
