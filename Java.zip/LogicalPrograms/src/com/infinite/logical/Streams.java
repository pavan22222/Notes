package com.infinite.logical;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Streams {

	public static void main(String[] args) {
		// allMatch();
		// anyMatch();
		// collect();
		// concat();
		// count();
		// distinct();
		//empty();
		//filter();
		//findAny();
		//findFirst();
		//limit();
		//max();
		//min();
		//flatMap();
		//sorted();
		//sorted(null);
		//sortedReversed();
		toArray();
	}

	// allMatch method
	public static void allMatch() {
		Map<String, Integer> map = new HashMap<String, Integer>();
		// map.put(null,1);
		map.put("Pavan", 2);
		map.put("James", 1);
		map.put("Andersan", 1);
		Set<String> set = map.keySet();
		System.out.println(set.stream().allMatch(ele -> ele.contains("a")));
	}

	// anyMatch method
	public static void anyMatch() {
		Map<String, Integer> map = new HashMap<String, Integer>();
		// map.put(null,1);
		map.put("Pavan", 2);
		map.put("James", 1);
		map.put("Andersan", 1);
		Set<String> set = map.keySet();
		System.out.println(set.stream().anyMatch(ele -> ele.equalsIgnoreCase("Pavan")));
	}

	// collect
	public static void collect() {
		Map<String, Integer> map = new HashMap<String, Integer>();
		// map.put(null,1);
		map.put("Pavan", 2);
		map.put("James", 1);
		map.put("Andersan", 1);
		Set<String> set = map.keySet();
		Set<String> filteredSet = set.stream().filter(ele -> ele.length() % 2 == 0).collect(Collectors.toSet());
		System.out.println(filteredSet);
	}

	// concat
	public static void concat() {
		Map<String, Integer> map1 = new HashMap<String, Integer>();
		map1.put("Pavan", 1);
		map1.put("James", 1);
		Map<String, Integer> map2 = new HashMap<String, Integer>();
		map2.put("Andersan", 1);
		Stream stream1 = Stream.of(map1);
		Stream stream2 = Stream.of(map2);
		Stream stream = Stream.concat(stream1, stream2);
		System.out.println(stream.findFirst());
	}

	// count
	public static void count() {
		Map<String, Integer> map1 = new HashMap<String, Integer>();
		map1.put("Pavan", 1);
		map1.put("James", 1);
		Map<String, Integer> map2 = new HashMap<String, Integer>();
		map2.put("Andersan", 1);
		Stream stream1 = Stream.of(map1);
		Stream stream2 = Stream.of(map2);
		Stream stream = Stream.concat(stream1, stream2);
		System.out.println(stream.count());
	}

	// distinct
	public static void distinct() {
		String[] args = new String[] { "Pavan", "Pavan", "James", "Anderson" };
		List<String> list = Arrays.asList(args);
		List<String> list1 = list.stream().distinct().collect(Collectors.toList());
		list1 = Arrays.asList(args);
		System.out.println(Arrays.equals(list.toArray(), list1.toArray()));
		System.out.println(list + "    " + list1);
	}

	// empty
	public static void empty() {
		Stream stream = Stream.empty();
		System.out.println(stream);
	}

	// filter
	public static void filter() {

		Product product1 = new Streams().new Product(1,"Shoes",new Date("2022/10/12"));
		Product product2 = new Streams().new Product(2,"Pant",new Date("2012/07/12"));
		Product product3 = new Streams().new Product(3,"Shirt",new Date("2010/10/12"));
		List<Product> list = Arrays.asList(product1,product2,product3);
		list.stream().filter(product -> product.getDom().compareTo(new Date("2012/07/12")) >= 0)
		                                      .collect(Collectors.toList()).forEach(System.out::println);
	}
	
	// findAny
	public static void findAny() {
		Product product1 = new Streams().new Product(1, "Shoes", new Date("2022/10/12"));
		Product product2 = new Streams().new Product(2, "Pant", new Date("2012/07/12"));
		Product product3 = new Streams().new Product(3, "Shirt", new Date("2010/10/12"));
		List<Product> list = Arrays.asList(product1, product2, product3);
		Optional optional = list.stream().findAny();
		System.out.println(optional);
	}
	
	// findFirst
	public static void findFirst() {
		Product product1 = new Streams().new Product(1, "Shoes", new Date("2022/10/12"));
		Product product2 = new Streams().new Product(2, "Pant", new Date("2012/07/12"));
		Product product3 = new Streams().new Product(3, "Shirt", new Date("2010/10/12"));
		List<Product> list = Arrays.asList(product2, product3,product1);
		Optional optional = list.stream().findFirst();
		System.out.println(optional);
	}

	// limit
	public static void limit() {
		Product product1 = new Streams().new Product(1, "Shoes", new Date("2022/10/12"));
		Product product2 = new Streams().new Product(2, "Pant", new Date("2012/07/12"));
		Product product3 = new Streams().new Product(3, "Shirt", new Date("2010/10/12"));
		List<Product> list = Arrays.asList(product2, product3, product1);
		List<Product> products  = list.stream().limit(89).collect(Collectors.toList());
		System.out.println(products);
	}
	
	// max
	public static void max() {
		Product product1 = new Streams().new Product(1, "Shoeseee", new Date("2022/10/12"));
		Product product2 = new Streams().new Product(2, "Pant", new Date("2012/07/12"));
		Product product3 = new Streams().new Product(3, "Shirt", new Date("2010/10/12"));
		List<Product> list = Arrays.asList(product2, product3, product1);
		Optional<Product> product = list.stream().max((product11, product12) -> {
			return product11.getName().length() > product12.getName().length() ? 1
					: product11.getName().length() < product12.getName().length() ? -1 : 0;
		});
		System.out.println(product.get());
	}
	
	
	public static void min() {
		List<Product> products=new ArrayList<Streams.Product>();
		Product product1 = new Streams().new Product(1, "Shoeseee", new Date("2022/10/12"));
		Product product2 = new Streams().new Product(2, "Pant", new Date("2012/07/12"));
		Product product3 = new Streams().new Product(3, "Shirt", new Date("2010/10/12"));
		products = Arrays.asList(product1,product2,product3);
		Product p1=products.stream().min((product11, product22) -> product11.getId() > product22.getId() ? 1
				: product11.getId() < product22.getId() ? -1 : 0).get();
		System.out.println(p1);
	}
	
	// If we want to store some values in stream object we can use of(T) method
	public static void of() {
		Stream stream = Stream.of("Pavan");
		System.out.println(stream.findFirst());
	}
	
	//flatMap
	public static void flatMap() {
		
		List<List<Product>> listOfAllProducts=new ArrayList<List<Product>>();
		List<Product> productsList1=new ArrayList<Streams.Product>();
		Product product11 = new Streams().new Product(1, "Shoes", new Date("2022/10/12"));
		Product product12 = new Streams().new Product(2, "Pant", new Date("2012/07/12"));
		Product product13 = new Streams().new Product(3, "Shirt", new Date("2010/10/12"));
		productsList1 = Arrays.asList(product11,product12,product13);
		
		List<Product> productsList2=new ArrayList<Streams.Product>();
		Product product21 = new Streams().new Product(1, "EarPhones", new Date("2022/10/12"));
		Product product22 = new Streams().new Product(2, "Charger", new Date("2012/07/12"));
		Product product23 = new Streams().new Product(3, "Mobile", new Date("2010/10/12"));
		productsList2 = Arrays.asList(product21,product22,product23);
		
		List<Product> productsList3=new ArrayList<Streams.Product>();
		Product product31 = new Streams().new Product(1, "TV", new Date("2022/10/12"));
		Product product32 = new Streams().new Product(2, "Refregirator", new Date("2012/07/12"));
		Product product33 = new Streams().new Product(3, "AC", new Date("2010/10/12"));
		productsList3 = Arrays.asList(product31,product32,product33);
		
		listOfAllProducts.add(productsList1);
		listOfAllProducts.add(productsList2);
		listOfAllProducts.add(productsList3);
		
		/*
		 * List<String> productsList =
		 * listOfAllProducts.stream().flatMap(list->list.stream().map(product->{
		 * product.setId(product.getId()*10); return product.getName();
		 */
		
		List<Product> productsList = listOfAllProducts.stream().flatMap(list->list.stream()).collect(Collectors.toList());
		
		System.out.println(productsList);
	}
	
	//sorted()
	public static void sorted() {
		Product product11 = new Streams().new Product(1, "ahoes", new Date("2022/10/12"));
		Product product12 = new Streams().new Product(2, "Aant", new Date("2012/07/12"));
		Product product13 = new Streams().new Product(3, "Shirt", new Date("2010/10/12"));
		List<Product> productsList = Arrays.asList(product11,product12,product13);
		productsList.stream().sorted().forEach(System.out::println);
	}

	// sorted(Comparator comparator)
	public static void sorted(Comparator comparator) {
		Product product11 = new Streams().new Product(1, "ahoes", new Date("2022/10/22"));
		Product product12 = new Streams().new Product(2, "Aant", new Date("2012/12/12"));
		Product product13 = new Streams().new Product(3, "Shirt", new Date("2010/10/01"));
		List<Product> productsList = Arrays.asList(product11, product12, product13);
		productsList.stream().sorted((product1,product2) -> {
			return product1.getDom().getDate() < product2.getDom().getDate() ? 1 :
				product1.getDom().getDate() > product2.getDom().getDate() ? -1 : 0 ;
		}).forEach(System.out::println);
	}
	
	// sorted(Comparator comparator)
		public static void sortedReversed() {
			Product product11 = new Streams().new Product(1, "ahoes", new Date("2022/10/22"));
			Product product12 = new Streams().new Product(2, "Aant", new Date("2012/12/12"));
			Product product13 = new Streams().new Product(3, "Shirt", new Date("2010/10/01"));
			List<Product> productsList = Arrays.asList(product11, product12, product13);
			//If we want to reverse the already sorted elements
			productsList.stream().sorted(Comparator.reverseOrder()).forEach(System.out::println);
			//productsList.stream().sorted(Comparator.comparing(Product :: getId).reversed()).forEach(System.out::println);
		}
		
		//toArray
		public static void toArray() {
			//new String().chars().mapToObj(i->(char)i).toArray(Character[] :: new);
			Product product11 = new Streams().new Product(1, "ahoes", new Date("2022/10/22"));
			Product product12 = new Streams().new Product(2, "Aant", new Date("2012/12/12"));
			Product product13 = new Streams().new Product(3, "Shirt", new Date("2010/10/01"));
			List<Product> productsList = Arrays.asList(product11, product12, product13);
			Product[] products = productsList.stream().sorted(Comparator.reverseOrder()).toArray(Product[] :: new);
			System.out.println(Arrays.deepToString(products));
			}

	public class Product implements Comparable<Product> {

		public Product() {

		}

		public Product(Integer id, String name, Date dom) {
			super();
			this.id = id;
			this.name = name;
			this.dom = dom;
		}

		private Integer id;
		private String name;
		private Date dom;

		public Integer getId() {
			return id;
		}

		public void setId(Integer id) {
			this.id = id;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public Date getDom() {
			return dom;
		}

		public void setDom(Date dom) {
			this.dom = dom;
		}
		
		@Override
		public String toString() {
			return "Product[ id="+id+",name ="+ name +",dom="+dom+"]";
		}

		@Override
		public int compareTo(Product product) {
			return this.getName().charAt(0) > product.getName().charAt(0)  ? 1
					: this.getName().charAt(0) < product.getName().charAt(0) ? -1 : 0 ;
		}


		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			Product other = (Product) obj;
			return Objects.equals(dom, other.dom) && Objects.equals(id, other.id) && Objects.equals(name, other.name);
		}


	}

}
