package com.infinite.logical;

import java.util.HashMap;
import java.util.Map;

public class Loops {

	public static void main(String[] args) {

		int i = 0;
		do {
			System.out.println("Pavan" + i);
			i++;
		} while (i < 10);

		String name = "James111";

		switch (name) {
		case "Pavan": {
			for (int j = 0; j < 100; j++) {
				System.out.println("Pavan" + j);
			}
			break;
		}
		case "James": {
			for (int j = 0; j < 100; j++) {
				System.out.println("James" + j);
			}
			break;
		}

		default: {
			for (int j = 0; j < 100; j++) {
				System.out.println("Default" + j);
			}
			break;
		}

		}
		
		System.out.println(findLeapYear(1300));
		mapOperations();
	}
	
	
	public static String findLeapYear(int year) {
		if((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)){
			return year +" is an Leap year";
		}
		return year +" is not an Leap year";
	}
	
	
	public static void mapOperations() {
		Map<String,Integer> map = new HashMap<String, Integer>();
		map.put("Pavan", null);
		map.put(null, null);
		map.put("Krish", null);
		System.out.println(map);
	}

}
