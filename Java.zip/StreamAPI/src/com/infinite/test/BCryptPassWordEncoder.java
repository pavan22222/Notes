package com.infinite.test;

public class BCryptPassWordEncoder {
	
	public static void main(String[] args) {
		
	}
}
