package com.infinite.test;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StreamAPITest {

	public static void main(String[] args) {
		Stream<String> stream1 = Stream.of("Lokanath", "Rakesh");

		Stream<String> stream2 = Stream.of("Pavan", "Srikanth", "Naveen", "Lokanath");
		Stream<String> stream3 = Stream.concat(stream1, stream2);
		// stream3.distinct().forEach(System.out::println);
		// stream3.filter(ele->ele.length() >
		// 4).collect(Collectors.toList()).forEach(System.out::println);
		// System.out.println(stream3.findFirst().get());
		List<String> list1= new ArrayList<String>();
		list1.add("A");list1.add("T");list1.add("B");
		List<String> list2= new ArrayList<String>();
		list1.add("C");list1.add("L");list1.add("A");
		List<List<String>> listOfLists= new ArrayList<List<String>>();
		listOfLists.add(list1);
		listOfLists.add(list2);
		listOfLists.stream().flatMap(list->list.stream()).collect(Collectors.toList()).forEach(System.out::println);
		System.out.println(list1.stream().allMatch(ele->"A".equalsIgnoreCase(ele)));
		
		
		Optional<Employee> optional=Optional.of(new StreamAPITest().new Employee());
		System.out.println(optional.isPresent());
		System.out.println(optional.empty());
		System.out.println(new StreamAPITest().new Employee().getObject(Employee.class));
		System.out.println(new StreamAPITest().new Employee().saveEmployee(new StreamAPITest().new Employee()));
		optional.ifPresent(data->new StreamAPITest().new Employee().getDetails(data.getName()));

	}
	
	
	public class Employee{
		private Integer id;
		private String name;
		
		
		
		public Integer getId() {
			return id;
		}

		public void setId(Integer id) {
			this.id = id;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public <T extends Employee> T saveEmployee(T t){
			return t;
		}
		
		public <S extends Employee> S getObject(Class<? extends Employee> T){
			return (S) new Employee();
		}
		
		public void getDetails(String s) {
			
		}
		
	}
	
	
	

}
