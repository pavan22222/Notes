package com.infinite.clientcomp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.loadbalancer.LoadBalancerClient;
import org.springframework.cloud.loadbalancer.annotation.LoadBalancerClients;
import org.springframework.stereotype.Component;

@Component("")
public class ClientComp {
	
	@Autowired
	private org.springframework.cloud.client.discovery.DiscoveryClient client;
	
	@Autowired
	private LoadBalancerClient loadBalancerClient;
	
	public String getProducerMSUrl() {
		/*
		 * List<ServiceInstance> instances = client.getInstances("ProducerApp-Service");
		 * return instances.get(0).getUri()+"/ProducerApp/product";
		 */
		
		ServiceInstance instance = loadBalancerClient.choose("ProducerApp-Service");
		return instance.getUri()+"/ProducerApp/product";
	}

}
