package com.infinite.repository;

import com.infinite.model.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;
import java.math.BigDecimal;
import java.sql.Types;
import java.util.List;
import java.util.Map;

@Repository
public class EmployeeRepository {

    @Autowired
    private SimpleJdbcCall call;

    /**

     create or replace PROCEDURE GET_EMPLOYEE_BY_ID(EID IN NUMBER,DETAILS OUT SYS_REFCURSOR)
     IS
     BEGIN
     OPEN DETAILS FOR
     SELECT * FROM EMPLOYEE WHERE ID=EID;

     END GET_EMPLOYEE_BY_ID;

     */

    public Employee getEmployeeById(Integer id){
        Employee emp=null;
        call.withProcedureName("GET_EMPLOYEE_BY_ID").declareParameters(new SqlParameter("EID", Types.INTEGER),
                (SqlParameter) new SqlOutParameter("DETAILS",Types.REF_CURSOR));
        MapSqlParameterSource inParams=new MapSqlParameterSource();
        inParams.addValue("EID",id);
        Map<String,Object> result=call.execute(inParams);
        if(result != null) {
            List<Map<String, Object>> list = (List<Map<String, Object>>) result.get("DETAILS");
            if (list != null) {
                Map<String, Object> map = list.get(0);
                emp = new Employee();
                emp.setId(map.get("ID") != null ? ((BigDecimal) map.get("ID")).intValue() : null);
                emp.setName(map.get("NAME") != null ? (String) map.get("NAME") : null);
                emp.setAge(map.get("AGE") != null ? ((BigDecimal) map.get("AGE")).intValue() : null);
                emp.setDesignation(map.get("DESIGNATION") != null ? (String) map.get("DESIGNATION") : null);
            }
        }
        return emp;
    }
}
