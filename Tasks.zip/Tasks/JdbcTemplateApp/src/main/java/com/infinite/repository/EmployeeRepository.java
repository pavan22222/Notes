package com.infinite.repository;

import com.infinite.model.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;
import java.math.BigDecimal;
import java.sql.Types;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class EmployeeRepository {

    private String GET_EMPLOYEE_BY_ID="SELECT * FROM EMPLOYEE WHERE ID=?";

    @Autowired
    private JdbcTemplate template;


    public Employee getEmployeeById(Integer id){
        Employee emp=null;
        return template.queryForObject(GET_EMPLOYEE_BY_ID,new Object[]{id},new BeanPropertyRowMapper<Employee>(Employee.class));
    }
}
