package com.infinite.test;

import com.infinite.beans.WelcomeMessageGenerator;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class Test {

    public static void main(String[] args) {
        ApplicationContext ctx=new FileSystemXmlApplicationContext("src/main/java/com/infinite/cfgs/spring.xml");
        WelcomeMessageGenerator generator=ctx.getBean("welcomeMessageGenerator",WelcomeMessageGenerator.class);
        System.out.println(generator.generateWelcome());
    }
}
