package com.infinite.beans;

import org.springframework.stereotype.Component;

@Component
public class WelcomeMessageGenerator {

    public String generateWelcome(){
        return "Welcome";
    }
}
